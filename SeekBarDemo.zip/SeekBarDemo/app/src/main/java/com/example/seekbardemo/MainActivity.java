package com.example.seekbardemo;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    ImageView imgColored,imgSmall;
    SeekBar seekbarColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgColored = findViewById(R.id.imgColored);
        imgSmall = findViewById(R.id.imgSmall);

        imgSmall.setImageResource(R.drawable.pic8);
        seekbarColor = findViewById(R.id.seekbarColor);

        seekbarColor.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int currentValue;
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                currentValue = i;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                imgColored.setBackgroundColor(Color.argb(255,0,currentValue,0));
            }
        });
    }
}